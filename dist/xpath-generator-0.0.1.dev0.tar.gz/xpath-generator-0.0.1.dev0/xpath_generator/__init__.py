from .spider_generator import SpiderGenerator

__all__ = [
	SpiderGenerator,
]
